# KS DATA SUB

A responsive front-end prototype for a Nigerian VTU app concept.

## Included in this demo
- Service screens for data, airtime, electricity and TV
- Sample wallet balance and demo add-funds interaction
- Local demo transaction history
- Responsive mobile-first layout

## Important
This is **only a front-end demo**. It does not connect to a VTU provider, bank, payment gateway, identity service, or real wallet. Demo transactions do not deliver services or move real money.

## Files
- `index.html` — page structure
- `style.css` — responsive styles
- `app.js` — demo interactions

## Run locally
Open `index.html` in a modern browser.

## Next steps before production
1. Choose a reputable VTU API provider and obtain credentials privately.
2. Build a secure backend; never put API secrets in browser code or a public repository.
3. Add real authentication, wallet ledger, idempotent transactions, reconciliation and audit logs.
4. Integrate a payment gateway and confirm its Nigerian compliance requirements.
5. Test failure cases and security before accepting customers.
