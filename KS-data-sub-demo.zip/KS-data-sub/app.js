const $ = (id) => document.getElementById(id);
let balance = 25000;
let transactions = [];
let activeService = "Data";
const naira = (n) => "₦" + Number(n).toLocaleString("en-NG", {minimumFractionDigits:2, maximumFractionDigits:2});
function renderBalance(){ $("balance").textContent = naira(balance); }
function renderTransactions(){
  const root = $("transactions");
  if(!transactions.length){ root.innerHTML = '<div class="empty"><span>↻</span><b>No transactions yet</b><small>Your demo transactions will appear here.</small></div>'; return; }
  root.innerHTML = transactions.slice().reverse().map(t => `<div class="transaction"><span class="tx-icon">${t.service==="Data"?"▤":t.service==="Airtime"?"↗":t.service==="Electricity"?"ϟ":"▣"}</span><div class="tx-details"><b>${t.service} · ${t.provider}</b><small>${t.target} · ${t.date}</small></div><span class="tx-amount">-${naira(t.amount)}</span></div>`).join("");
}
function showMessage(title, text){ $("messageTitle").textContent=title; $("messageText").textContent=text; $("messageDialog").showModal(); }
function setService(service){
  activeService=service;
  $("dialogTitle").textContent = service==="TV"?"TV Subscription":service==="Electricity"?"Electricity Bill":service==="Airtime"?"Buy Airtime":"Buy Data";
  $("dialogSubtitle").textContent = "Preview a sample " + service.toLowerCase() + " transaction";
  $("phoneLabel").textContent = service==="Electricity"?"Meter number":service==="TV"?"Smartcard / IUC number":"Phone number";
  $("phone").placeholder = service==="Electricity"?"Enter meter number":service==="TV"?"Enter smartcard number":"08012345678";
  $("planWrap").style.display = service==="Data"?"block":"none";
  $("network").innerHTML = service==="TV" ? '<option>DStv</option><option>GOtv</option><option>StarTimes</option>' : service==="Electricity" ? '<option>Abuja Electricity</option><option>Ikeja Electric</option><option>Kano Electric</option><option>Jos Electric</option><option>Other provider</option>' : '<option>MTN</option><option>Airtel</option><option>Glo</option><option>9mobile</option>';
  $("amount").value = service==="Data"?500:service==="Airtime"?500:service==="Electricity"?2000:3000;
  $("serviceDialog").showModal();
}
document.querySelectorAll("[data-service]").forEach(btn=>btn.addEventListener("click",()=>setService(btn.dataset.service)));
$("plan").addEventListener("change",()=>{if(activeService==="Data") $("amount").value=$("plan").value;});
$("serviceForm").addEventListener("submit",(e)=>{
  e.preventDefault();
  const target=$("phone").value.trim();
  const amount=Number($("amount").value);
  const provider=$("network").value;
  if(!target || !Number.isFinite(amount) || amount<=0){showMessage("Check your details","Enter a valid recipient or meter number and amount.");return;}
  if(amount>balance){showMessage("Insufficient demo balance","This sample wallet does not have enough demo funds. Use Add funds (demo) to test.");return;}
  balance-=amount;
  transactions.push({service:activeService,provider,target,amount,date:new Date().toLocaleString("en-NG",{dateStyle:"medium",timeStyle:"short"})});
  renderBalance();renderTransactions();$("serviceDialog").close();
  showMessage("Demo transaction recorded", "A sample " + activeService.toLowerCase() + " transaction for " + naira(amount) + " was added to your local demo history. No real payment was taken and no service was delivered.");
});
$("addFunds").addEventListener("click",()=>{balance+=5000;renderBalance();showMessage("Demo funds added","₦5,000 has been added to the sample wallet for testing only. No real money was deposited.");});
function showHistory(){ $("activity").scrollIntoView({behavior:"smooth",block:"start"}); if(!transactions.length)showMessage("No history yet","Try a sample service to see how transaction history works."); }
$("historyBtn").addEventListener("click",showHistory);$("allHistory").addEventListener("click",showHistory);
$("profileBtn").addEventListener("click",()=>showMessage("KS DATA SUB profile","This is a prototype profile. Account registration and login have not been connected yet."));
$("messageClose").addEventListener("click",()=>$("messageDialog").close());$("messageOk").addEventListener("click",()=>$("messageDialog").close());
renderBalance();renderTransactions();